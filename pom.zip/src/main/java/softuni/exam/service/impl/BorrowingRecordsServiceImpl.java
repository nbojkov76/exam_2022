package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.BorrowingRecordsRootDto;
import softuni.exam.models.entity.BorrowingRecord;
import softuni.exam.repository.BorrowingRecordRepository;
import softuni.exam.service.BookService;
import softuni.exam.service.BorrowingRecordsService;
import softuni.exam.service.LibraryMemberService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class BorrowingRecordsServiceImpl  implements BorrowingRecordsService {

    private static final String BORROW_PATH = "src/main/resources/files/xml/borrowing-records.xml";
    private final BorrowingRecordRepository borrowingRecordRepository;

    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final BookService bookService;

    private final LibraryMemberService libraryMemberService;
    
    private final XmlParser xmlParser;

    public BorrowingRecordsServiceImpl(BorrowingRecordRepository borrowingRecordRepository, ModelMapper modelMapper, ValidationUtil validationUtil, BookService bookService, LibraryMemberService libraryMemberService, XmlParser xmlParser) {
        this.borrowingRecordRepository = borrowingRecordRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.bookService = bookService;
        this.libraryMemberService = libraryMemberService;
        this.xmlParser = xmlParser;
    }

    @Override
    public boolean areImported() {
        return borrowingRecordRepository.count() > 0;
    }

    @Override
    public String readBorrowingRecordsFromFile() throws IOException {
        return Files.readString(Path.of(BORROW_PATH));
    }

    @Override
    public String importBorrowingRecords() throws IOException, JAXBException {
        
        StringBuilder sb = new StringBuilder();


                xmlParser.fromFile(BORROW_PATH, BorrowingRecordsRootDto.class)
                        .getBorrows()
                            .stream()
                        .filter(borrowingRecordSeedDto -> {
                               boolean isValid = validationUtil.isValid(borrowingRecordSeedDto)
                                       || !bookService.isEntityExist(borrowingRecordSeedDto.getBook().getTitle())
                                      || !libraryMemberService.isExistByGivenId(borrowingRecordSeedDto.getMember().getId());

                               sb.append(isValid ? String.format("Successfully imported borrowing record " +
                                       "%s - %s", borrowingRecordSeedDto.getBook().getTitle(), borrowingRecordSeedDto.getBorrowDate()):
                                       "Invalid borrowing record").append(System.lineSeparator());

                                    return isValid;

                            }).map(borrowingRecordSeedDto -> {
                                BorrowingRecord borrowingRecord = modelMapper.map(borrowingRecordSeedDto, BorrowingRecord.class);
                                borrowingRecord.setBook(bookService.findByBookTitle(borrowingRecordSeedDto.getBook().getTitle()));
                                borrowingRecord.setMember(libraryMemberService.findById(borrowingRecord.getMember().getId()));

                                    return borrowingRecord;
                        }).forEach(borrowingRecordRepository::save);


        return sb.toString();
    }

    @Override
    public String exportBorrowingRecords() {
        return null;
    }
}
